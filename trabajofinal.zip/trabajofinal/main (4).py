import tkinter as tk
import re
import os

class LexicalAnalyzerApp:
    def __init__(self, master):
        self.master = master
        master.title("Interfaz Gráfica - Lenguajes de Programación")

        # Crear un marco para el encabezado
        self.header_frame = tk.Frame(master)
        self.header_frame.pack(side=tk.TOP, pady=10)

        # Agregar una etiqueta para el título
        self.title_label = tk.Label(self.header_frame, text="UNIVERSIDAD EAFIT PROYECTO FINAL DE LENGUAJES DE PROGRAMACION", font=("Helvetica", 14, "bold"))
        self.title_label.pack(side=tk.LEFT, padx=10)

        # Ruta a la imagen que deseas mostrar
        self.image_path = "logo_eafit_completo.png"

        # Agregar un lienzo para la imagen
        self.image_canvas = tk.Canvas(self.header_frame, width=50, height=50)
        self.image_canvas.pack(side=tk.LEFT)
        self.show_image()

        # Etiqueta para indicar al usuario que ingrese un texto
        self.label_ingreso = tk.Label(master, text="Ingrese un texto:")
        self.label_ingreso.pack(pady=5)

        self.text_entry = tk.Entry(master, width=50)
        self.text_entry.pack(pady=10)

        self.analyze_button = tk.Button(master, text="Procesar Cadena de texto", command=self.analyze_text)
        self.analyze_button.pack(pady=5)

        self.result_label = tk.Label(master, text="")
        self.result_label.pack(pady=10)

        self.emoticon_label = tk.Label(master, text="Emoticones encontrados:")
        self.emoticon_label.pack(pady=5)

        self.emoticon_canvas = tk.Canvas(master, width=500, height=100)
        self.emoticon_canvas.pack()

        # Ruta a la carpeta de emoticones en alta definición
        self.emoticon_folder_path = r"C:\Users\DELL\Downloads\emojis"

        # Cargar el diccionario al inicializar la aplicación
        self.diccionario = cargar_diccionario()
        

    def analyze_text(self):
        text_input = self.text_entry.get()
        palabras, e_espanolmoticones = analizador_lexicografico(text_input, self.diccionario)

        # Construir una cadena que incluya el texto y los emoticones
        resultado = f"Salida: {text_input} ("
        resultado += ', '.join(palabras)
        resultado += ") " + " ".join(f"({emoticon})" for emoticon in e_espanolmoticones)

        # Mostrar el resultado en la etiqueta
        self.result_label.config(text=resultado)

        # Mostrar los emoticones en la interfaz gráfica
        self.show_emoticons(e_espanolmoticones)

    def show_emoticons(self, emoticon_list):
        self.emoticon_canvas.delete("all")
        x_offset = 10
        for emoticon in emoticon_list:
            # Asegúrate de tener imágenes con el formato correcto (por ejemplo, .png)
          emoticon_filename = emoticon.replace(":", "_")
          img_path = os.path.join(self.emoticon_folder_path, f"{emoticon}.png").replace("\\", "/")
          img = tk.PhotoImage(file=img_path)
          self.emoticon_canvas.create_image(x_offset, 50, anchor=tk.W, image=img)
          x_offset += 50

    def show_image(self):
        # Asegúrate de tener imágenes con el formato correcto (por ejemplo, .png)
        if os.path.exists(self.image_path):
            img = tk.PhotoImage(file=self.image_path)
            self.image_canvas.create_image(0, 0, anchor=tk.NW, image=img)
            # Asigna la imagen a una referencia para evitar que sea eliminada por el recolector de basura
            self.image_canvas.image = img

def cargar_diccionario():
    diccionario = set()

    # Ruta a la carpeta que contiene archivos por letras
    archivo_diccionario = "diccionario.txt"

    if os.path.exists(archivo_diccionario):
            with open(archivo_diccionario, "r", encoding="utf-8") as file:
                    diccionario.update(word.strip() for word in file)

            return diccionario

def analizador_lexicografico(texto, diccionario):
    # Expresión regular para identificar palabras en español
    palabras_espanol = [palabra for palabra in re.findall(r'\b[a-zA-ZáéíóúÁÉÍÓÚñÑ]+\b', texto) if palabra in diccionario]

    # Expresión regular para identificar emoticones
    emoticones_regex = r'(:\)|:\(|:D|;\)|:P|xD|:-\)|:-\(|\(y\)|\(n\)|<3|\\m/|:-O|:O|:-\||:\||:\*|>:\(|\^\^|:-\])'
    emoticones = re.findall(emoticones_regex, texto)

    return palabras_espanol, emoticones

if __name__ == "__main__":
    root = tk.Tk()
    app = LexicalAnalyzerApp(root)
    root.mainloop()



